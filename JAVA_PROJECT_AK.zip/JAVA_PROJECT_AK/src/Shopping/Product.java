package Shopping;

public class Product {
    private int productId;
    private String productName;
    private String productCategory;
    private double price;

    public Product(int productId, String productName, String productCategory, double price) {
        this.productId = productId;
        this.setProductName(productName);
        this.productCategory = productCategory;
        this.price = price;
    }

	private void setProductName(String productName2) {
		// TODO Auto-generated method stub
		
	}

	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getProductId() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getProductName() {
		// TODO Auto-generated method stub
		return null;
	}


    // Getters and setters
}