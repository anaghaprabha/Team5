package Shopping;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private List<Product> products;

    public Inventory() {
        products = new ArrayList<>();
        // Hardcoded product inventory
        products.add(new Product(1, "Product 1", "Category 1", 10.99));
        products.add(new Product(2, "Product 2", "Category 2", 9.99));
        products.add(new Product(3, "Product 3", "Category 3", 12.99));
    }

    public Product getProductById(int productId) {
        for (Product product : products) {
        	if (product.getProductId().equals(String.valueOf(productId)));

            }
        
        return null;
    }

	public Product searchProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}


}
