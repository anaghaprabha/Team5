package Shopping;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<Product> products;
    private double total;

    public ShoppingCart() {
        products = new ArrayList<>();
        total = 0.0;
    }

    public void addProduct(Product product, int quantity) {
        products.add(product);
        total += product.getPrice() * quantity;
    }

    public void viewCart() {
        for (Product product : products) {
            System.out.println(product.getProductId() + " " + product.getProductName() + " " + product.getPrice());
        }
        System.out.println("Total: " + total);
    }

    public void checkout() {
        System.out.println("Checkout successful. Total amount: " + total);
        products.clear();
        total = 0.0;
    }
}

