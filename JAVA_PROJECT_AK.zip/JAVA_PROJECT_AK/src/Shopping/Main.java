package Shopping;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        ShoppingCart cart = new ShoppingCart();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Search for Products");
            System.out.println("2. Add to Shopping Cart");
            System.out.println("3. View Shopping Cart");
            System.out.println("4. Checkout Shopping Cart");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter product name:");
                    String productName = scanner.next();
                    // Search product by name (not implemented)
                    break;
                case 2:
                    System.out.println("Enter product id:");
                    int productId = scanner.nextInt();
                    System.out.println("Enter quantity:");
                    int quantity = scanner.nextInt();
                    Product product = inventory.searchProduct(productId);
                    if (product != null) {
                        cart.addProduct(product, quantity);
                    } else {
                        System.out.println("Product not found");
                    }
                    break;
                case 3:
                    cart.viewCart();
                    break;
                case 4:
                    cart.checkout();
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}