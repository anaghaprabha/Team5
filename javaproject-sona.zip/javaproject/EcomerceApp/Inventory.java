package com.javaproject.EcomerceApp;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
	    private List<Product> products;

	    public Inventory() {
	        products = new ArrayList<>();
	        products.add(new Product(1, "Apple", "Mobile", 400000.9));
	        products.add(new Product(2, "Dell", "Laptop", 99999.99));
	        products.add(new Product(3, "Vivo", "Mobile", 890989.99));
	        products.add(new Product(4, "MAC", "Laptop", 999999.99));
	        products.add(new Product(5, "Jeans", "Pants", 2500));
	        products.add(new Product(6, "Cable", "USB", 1399.99));
	        products.add(new Product(7, "Jumka", "Earing", 999.89));
	    }

	    public Product searchProduct(int productId) {
	        for (Product product : products) {
	            if (product.getProductId() == productId) {
	                return product;
	            }
	        }
	        return null;
	    }

		public List<Product> getProducts() {
			return products;
		}

		public void setProducts(List<Product> products) {
			this.products = products;
		}
	   

		
}
