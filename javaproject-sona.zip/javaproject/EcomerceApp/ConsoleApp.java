package com.javaproject.EcomerceApp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ConsoleApp {
    private Inventory inventory;
    private ShoppingCart shoppingCart;
    private Scanner scanner;

   
    public ConsoleApp() {
        inventory = new Inventory();
        shoppingCart = new ShoppingCart();
        
    }

    public void run()  {
    	ShoppingCartView shoppingcartView = new ShoppingCartView(shoppingCart);
    	Scanner scanner = new Scanner(System.in);   	
    	 while (true) {
            System.out.println("1. Search for Products");
            System.out.println("2. Add to Shopping Cart");
             System.out.println("3. View Shopping Cart");
            System.out.println("4. Checkout Shopping Cart");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            //scanner.nextLine();         
            //scanner.nextLine();
            switch (choice) {
                case 1:
                	
                	System.out.println("Searching for products...");
                	System.out.println("Enter product name: ");
                	String productName=scanner.nextLine();
                    System.out.println("Product entered by customer: "+productName);
                    break;
                case 2:
                    addProductToCart(scanner);
                    break;
                case 3:
                    System.out.println("Viewing Shopping Cart: ");
                    shoppingcartView.viewShoppingCart();
                    
                    System.out.println("Press any key to continue....");
                    scanner.nextLine();
                    break;
                case 4:
                    checkoutShoppingCart();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    System.out.println("Thanks for Visiting.....meet you again");
                    scanner.close();
                    return;
                    
                default:
                    System.out.println("Invalid choice...Please try again");
            }
    	 }
            
        }
    
            
       
    

    public void searchProducts(Scanner scanner) {
    	
    	System.out.println("Search for Products..");
        System.out.print("Enter product name:");
        String productName = scanner.nextLine();
        //System.out.println("Input read: "+productName);
        System.out.println("Searching for product: "+productName);
        //
        System.out.println("length"+productName.length());
        //scanner.close();
        // Search products in inventory
    }

    public void addProductToCart(Scanner scanner) {
    	System.out.println("Add to Shopping cart");
        System.out.println("Enter product id:");
        int productId=scanner.nextInt();
        scanner.nextLine();
        Product product = inventory.searchProduct(productId);
        System.out.println("Product searched: "+product);
        if(product!=null) {
        	System.out.println("Enter quantity:");
            int quantity = scanner.nextInt();
            System.out.println("Quantity entered: "+quantity);
            scanner.nextLine();
            shoppingCart.addProduct(product, quantity);
            System.out.println("Product added successfully....moving on....");
        }
        else {
        	System.out.println("Sorry...Product not found");
        }
    }

    public static class ShoppingCartView {
    	private ShoppingCart shoppingCart;
   	 ArrayList<String> cart = new ArrayList<>();
   	 public ShoppingCartView(ShoppingCart shoppingCart) {
   		 this.shoppingCart=shoppingCart;
   	 }
   
    
    public void viewShoppingCart() {
        System.out.println("Cart contains: ");
        for(Product product : shoppingCart.getProducts()) {
        	System.out.println(product);
        }
    }
    }

    public void checkoutShoppingCart() {
       System.out.println("Checking out shopping cart...");
       for(Product product : shoppingCart.getProducts()) {
       	System.out.println(product.getProductName()+" & "+product.getQuantity());
       }
       double totalCost=shoppingCart.getTotal();
       System.out.println("Total Cost: $"+totalCost);
       System.out.println("Processing payment....");
       shoppingCart.clearCart();
       System.out.println("Checkout complete..Thank you for shopping with us!!!");
    }

    
    
    public static void main(String[] args)  {
        ConsoleApp app = new ConsoleApp();
        app.run();
    }
}
