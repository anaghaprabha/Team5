package com.javaproject.EcomerceApp;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
	private List<Product> products;
    private double total;
    private int quantity;

    public ShoppingCart() {
        products = new ArrayList<>();
        this.products=products;
        this.quantity=quantity;
    }

    // Add product to cart, update total
    public void addProduct(Product product, int quantity) {
        products.add(product);
        total += product.getPrice() * quantity;
    }

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double caluculateTotalCost() {
    	double totalCost=0;
    	for(Product product:products) {
    		totalCost+=product.getPrice();
    	}
    	
		return totalCost;
    }
    public void clearCart() {
    	products.clear();
    }
}
