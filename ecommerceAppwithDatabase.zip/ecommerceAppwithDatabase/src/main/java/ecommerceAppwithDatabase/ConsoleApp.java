package ecommerceAppwithDatabase;



import java.sql.*;
import java.util.*;

public class ConsoleApp {
    private Connection connection;
    private Scanner scanner;
    private List<Product> shoppingCart = new ArrayList<>();
    private ProductInterface productInterface;


    public ConsoleApp() throws Exception {
        this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart", "root", "pass@word1");
        this.scanner = new Scanner(System.in);
        this.productInterface = new Inventory();
    }

    public void run() {
    	
        while (true) {
            System.out.println("Main Menu:");
            System.out.println("1. List All Products");
            System.out.println("2. Search products");
            System.out.println("3. Added to cart");
            System.out.println("4. View shopping cart");
            System.out.println("5. Remove from shopping cart");
            System.out.println("6. Checkout");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
            case 1: 
            	listAllProducts();
            	break;
                case 2:
                    searchProducts();
                    break;
                case 3:
                	addToCart();
                	break;
                case 4:
                    viewShoppingCart();
                    break;
                case 5:
                    removeFromCart();
                    break;
                case 6:
                    checkout();
                    break;
                case 7:
                    
                	System.out.println("Exiting...");
                    System.out.println("Thank you for shopping with us.....see you soon");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void searchProducts() {
        System.out.print("Enter product name or ID: ");
        String input = scanner.nextLine();
        try {
            int id = Integer.parseInt(input);
            searchProductById(id);
        } catch (NumberFormatException e) {
            searchProductByName(input);
        }
    }

    private void searchProductById(int id) {
        Product product = productInterface.getProduct(id);
        if (product != null) {
            System.out.println(product.toString());
        } else {
            System.out.println("Product not found");
        }
    }

    private void searchProductByName(String name) {
        List<Product> products = productInterface.getAllProducts();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(name.toLowerCase())) {
                System.out.println(product.toString());
            }
        }
    }
   
    private void listAllProducts() {
        List<Product> products = productInterface.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("No products found");
        } else {
            for (Product product : products) {
                System.out.println(product.toString());
            }
        }
    }
    
    private void addToCart() {
        System.out.print("Enter product ID or name: ");
        String input = scanner.nextLine();
        try {
            int id = Integer.parseInt(input);
            addProductToCartById(id);
        } catch (NumberFormatException e) {
            addProductToCartByName(input);
        }
    }

    private void addProductToCartById(int id) {
        Product product = productInterface.getProduct(id);
        if (product != null) {
            System.out.print("Enter quantity: ");
            int quantity = Integer.parseInt(scanner.nextLine());
            if (product.getQuantity() >= quantity) {
                shoppingCart.add(new Product(product.getId(), product.getName(), product.getPrice(), quantity));
                System.out.println("Product added to cart successfully!");
            } else {
                System.out.println("Not enough quantity available");
            }
        } else {
            System.out.println("Product not found");
        }
    }

    private void addProductToCartByName(String name) {
        List<Product> products = productInterface.getAllProducts();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(name.toLowerCase())) {
                System.out.print("Enter quantity: ");
                int quantity = Integer.parseInt(scanner.nextLine());
                if (product.getQuantity() >= quantity) {
                    shoppingCart.add(new Product(product.getId(), product.getName(), product.getPrice(), quantity));
                    System.out.println("Product added to cart successfully!");
                } else {
                    System.out.println("Not enough quantity available");
                }
                return;
            }
        }
        System.out.println("Product not found");
    }

    private void viewShoppingCart() {
        System.out.println("Shopping Cart:");
        System.out.println("------------------");
        for (Product product : shoppingCart) {
            System.out.printf("%d | %s | Quantity: %d | Price: $%.2f | Total: $%.2f\n", product.getId(), product.getName(), product.getQuantity(), product.getPrice(), product.getPrice() * product.getQuantity());
        }
        System.out.println("------------------");
        System.out.printf("Total Cost: $%.2f\n", calculateTotal());
    }

    private double calculateTotal() {
        double total = 0;
        for (Product product : shoppingCart) {
            total += product.getPrice() * product.getQuantity();
        }
        return total;
    }

    private void removeFromCart() {
        System.out.print("Enter product ID or name to remove: ");
        String input = scanner.nextLine();
        try {
            int id = Integer.parseInt(input);
            removeProductFromCartById(id);
        } catch (NumberFormatException e) {
            removeProductFromCartByName(input);
        }
    }

    private void removeProductFromCartById(int id) {
        Product productToRemove = null;
        for (Product product : shoppingCart) {
            if (product.getId() == id) {
                productToRemove = product;
                break;
            }
        }
        if (productToRemove != null) {
            System.out.print("Enter quantity to remove: ");
            int quantityToRemove = Integer.parseInt(scanner.nextLine());
            if (productToRemove.getQuantity() <= quantityToRemove) {
                shoppingCart.remove(productToRemove);
                System.out.println("Product removed from cart");
            } else {
                productToRemove.setQuantity(productToRemove.getQuantity() - quantityToRemove);
                System.out.println("Product quantity reduced in cart");
            }
        } else {
            System.out.println("Product not found in cart");
        }
    }


    private void removeProductFromCartByName(String name) {
        Product productToRemove = null;
        for (Product product : shoppingCart) {
            if (product.getName().toLowerCase().contains(name.toLowerCase())) {
                productToRemove = product;
                break;
            }
        }
        if (productToRemove != null) {
            System.out.print("Enter quantity to remove: ");
            int quantityToRemove = Integer.parseInt(scanner.nextLine());
            if (productToRemove.getQuantity() <= quantityToRemove) {
                shoppingCart.remove(productToRemove);
                System.out.println("Product removed from cart");
            } else {
                productToRemove.setQuantity(productToRemove.getQuantity() - quantityToRemove);
                System.out.println("Product quantity reduced in cart");
            }
        } else {
            System.out.println("Product not found in cart");
        }
    }


    private void checkout() {
        if (shoppingCart.isEmpty()) {
            System.out.println("Shopping cart is empty!");
            return;
        }
        double total = 0;
        for (Product product : shoppingCart) {
            total += product.getPrice() * product.getQuantity();
        }
        System.out.println("Total: $" + total);
        // Process payment (implementation omitted for brevity)
        System.out.println("Payment processed successfully!");
        // Update product quantities in database
        for (Product product : shoppingCart) {
            productInterface.updateProductQuantity(product.getId(), product.getQuantity());
        }
        // Clear shopping cart
        shoppingCart.clear();
        System.out.println("Thank you for shopping with us! Your order has been placed successfully.");
    }

    public static void main(String[] args) throws Exception {
        new ConsoleApp().run();
    }
}