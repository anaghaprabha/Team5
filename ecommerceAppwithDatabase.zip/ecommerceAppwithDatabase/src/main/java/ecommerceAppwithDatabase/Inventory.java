package ecommerceAppwithDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Inventory implements ProductInterface {
    private List<Product> products;

    public Inventory() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
        String username = "root";
        String password = "pass@word1";
        try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO products (name, price, quantity) VALUES (?, ?, ?)")) {
            pstmt.setString(1, product.getName());
            pstmt.setDouble(2, product.getPrice());
            pstmt.setInt(3, product.getQuantity());
            pstmt.executeUpdate();
            System.out.println("Product added to inventory successfully!");
        } catch (SQLException e) {
            System.err.println("Error adding product to inventory: " + e.getMessage());
        }
    }

    public void removeProduct(int id, int quantity) {
        String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
        String username = "root";
        String password = "pass@word1";
        try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE products SET quantity = quantity - ? WHERE id = ?")) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            System.out.println("Product quantity reduced successfully!");
        } catch (SQLException e) {
            System.err.println("Error reducing product quantity: " + e.getMessage());
        }
    }

    public void updateProduct(Product product) {
        String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
        String username = "root";
        String password = "pass@word1";
        try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE products SET name = ?, price = ?, quantity = ? WHERE id = ?")) {
            pstmt.setString(1, product.getName());
            pstmt.setDouble(2, product.getPrice());
            pstmt.setInt(3, product.getQuantity());
            pstmt.setInt(4, product.getId());
            pstmt.executeUpdate();
            System.out.println("Product updated in inventory successfully!");
        } catch (SQLException e) {
            System.err.println("Error updating product in inventory: " + e.getMessage());
        }
    }
    
    public Product getProduct(String name) {
        String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
        String username = "root";
        String password = "pass@word1";
        try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM products WHERE name = ?")) {
            pstmt.setString(1, name);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int productId = rs.getInt("id");
                    String Productname = rs.getString("name");
                    double price = rs.getDouble("price");
                    int quantity = rs.getInt("quantity");
                    return new Product(productId, Productname, price, quantity);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting product from inventory: " + e.getMessage());
        }
        return null;
    }

    public List<Product> getAllProducts() {
        String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
        String username = "root";
        String password = "pass@word1";
        try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM products")) {
            try (ResultSet rs = pstmt.executeQuery()) {
                List<Product> products = new ArrayList<>();
                while (rs.next()) {
                    int productId = rs.getInt("id");
                    String name = rs.getString("name");
                    double price = rs.getDouble("price");
                    int quantity = rs.getInt("quantity");
                    Product product = new Product(productId, name, price, quantity);
                    products.add(product);
                }
                return products;
            }
        } catch (SQLException e) {
            System.err.println("Error getting all products from inventory: " + e.getMessage());
        }
        return new ArrayList<>();
    }
    
    @Override
    public void updateProductQuantity(int id, int quantity) {
        String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
        String username = "root";
        String password = "pass@word1";
        try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE products SET quantity = quantity - ? WHERE id = ?")) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating product quantity: " + e.getMessage());
        }
    }

	@Override
	public void removeProduct(int id) {
	    String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
	    String username = "root";
	    String password = "pass@word1";
	    try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
	         PreparedStatement pstmt = conn.prepareStatement("DELETE FROM products WHERE id = ?")) {
	        pstmt.setInt(1, id);
	        pstmt.executeUpdate();
	        System.out.println("Product removed from inventory successfully!");
	    } catch (SQLException e) {
	        System.err.println("Error removing product from inventory: " + e.getMessage());
	    }
	}


	@Override
	public Product getProduct(int id) {
	    String dbUrl = "jdbc:mysql://localhost:3306/shopping_cart";
	    String username = "root";
	    String password = "pass@word1";
	    try (Connection conn = DriverManager.getConnection(dbUrl, username, password);
	         PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM products WHERE id = ?")) {
	        pstmt.setInt(1, id);
	        try (ResultSet rs = pstmt.executeQuery()) {
	            if (rs.next()) {
	                int productId = rs.getInt("id");
	                String name = rs.getString("name");
	                double price = rs.getDouble("price");
	                int quantity = rs.getInt("quantity");
	                return new Product(productId, name, price, quantity);
	            }
	        }
	    } catch (SQLException e) {
	        System.err.println("Error getting product from inventory: " + e.getMessage());
	    }
	    return null;
	}



}
