package ecommerceAppwithDatabase;

import java.util.List;

public interface ProductInterface {
    void addProduct(Product product);
    void removeProduct(int id);
    void updateProduct(Product product);
    Product getProduct(int id);
    List<Product> getAllProducts();
    void updateProductQuantity(int id, int quantity);
}