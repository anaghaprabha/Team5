package com.ecom.service;

public interface CartService {

	void addProductToCart(int productId, int quantity) throws Exception;

	void removeProductFromCart(int productId) throws Exception;

	ShoppingCart viewCart();

	void checkout();

}
