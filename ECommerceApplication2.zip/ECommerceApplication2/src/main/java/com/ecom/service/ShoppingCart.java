package com.ecom.service;
import com.ecom.data.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShoppingCart {
	private List<ViewCartItem> items = new ArrayList<>();;

	public List<ViewCartItem> getItems() {
		return items;
	}

	public void setItems(List<ViewCartItem> items) {
		this.items = items;
	}

	@Override
	public String toString() {
		viewCart();
		return "\nTotal Price =" + getTotal();
	}
	
	public void viewCart() {
		for (ViewCartItem item : items) {
			System.out.println(item.toString());
		}
		
	}

	public void addItem(Product product, int quantity) {
		int stockCount = product.getQuantity();
		for (ViewCartItem item : items) {
			try {
				if (item.getProduct().getProductId() == product.getProductId()) {
					item = new ViewCartItem(product, quantity);

				}
			} catch (NullPointerException e) {
				System.out.println("Product is out of stock" + e);
			}

		}
		items.add(new ViewCartItem(product, quantity));
		stockCount = stockCount - quantity;
		product.setQuantity(stockCount);
	}

	public void removeItem(int productId) {
		items.remove(productId);
	}

	public double getTotal() {
		double total = 0;
		for (ViewCartItem item : items) {
			total += item.getTotalPrice();
		}
		// items.clear();
		return total;
	}
}
