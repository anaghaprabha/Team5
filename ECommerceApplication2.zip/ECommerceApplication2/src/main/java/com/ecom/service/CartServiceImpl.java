package com.ecom.service;
import com.ecom.data.*;


public class CartServiceImpl implements CartService {
    private Inventory inventory;
    private ShoppingCart cart = new ShoppingCart();

    public CartServiceImpl(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public void addProductToCart(int productId, int quantity) throws Exception {
        Product product = inventory.getProductById(productId);
        if (product.getQuantity() < quantity) {
            throw new Exception("Product is currently out of stock, please check back later");
        }
        cart.addItem(product, quantity);
        System.out.println("Below Product has been added to cart.");
		System.out.println("ID | Name | Category | Specifications \t| Price | Quantity");
		System.out.println("------------------------------------------------------------------------");
        System.out.println(product.toString());
        System.out.println("------------------------------------------------------------------------");
		System.out.println("End of Display\n");
        int stockCount = product.getQuantity() - quantity;
        inventory.updateProductQuantity(productId, stockCount);
    }

    @Override
    public void removeProductFromCart(int productId) throws Exception {
        ViewCartItem item = cart.getItems().get(productId);
        if (item != null) {
            Product product = inventory.getProductById(productId);
            inventory.updateProductQuantity(productId, product.getQuantity() + item.getQuantity());
            System.out.println("ID | Name | Category | Specifications \t| Price | Quantity");
    		System.out.println("------------------------------------------------------------------------");
            System.out.println(product.getProductName());
            System.out.println("------------------------------------------------------------------------");
    		System.out.println("End of Display\n");
            cart.removeItem(productId);
           
        } else {
            throw new Exception("Product is not present in cart");
        }
    }

    @Override
    public ShoppingCart viewCart() {
        return cart;
    }

    @Override
    public void checkout() {
        System.out.println(cart);
        System.out.println("Thank you for shopping with us!");
        cart = new ShoppingCart(); // To Clear the cart after checkout
    }
}
