/**
 * 
 */
/**
 * 
 */
module JavaInitialProject {
}