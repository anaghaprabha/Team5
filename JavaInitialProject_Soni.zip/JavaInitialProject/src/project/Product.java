package project;

public class Product {

	private int productId;
    private String productName;
    private String productCategory;
    private double price;

    // Constructor
    public Product(int productId, String productName, String productCategory, double price) {
        this.productId = productId;
        this.productName = productName;
        this.productCategory = productCategory;
        this.price = price;
    }

    // Getters
    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public double getPrice() {
        return price;
    }

    // toString method for easy display
    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + productName + ", Category: " + productCategory + ", Price: " + price;
    }
}
