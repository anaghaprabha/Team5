package project;

import java.util.Scanner;

public class ECommerceApp {
    private static Inventory inventory = new Inventory();
    private static ShoppingCart cart = new ShoppingCart();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- E-Commerce Menu ---");
            System.out.println("1. Search for Products");
            System.out.println("2. Add Product to Cart");
            System.out.println("3. View Shopping Cart");
            System.out.println("4. Checkout Shopping Cart");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    searchProducts();
                    break;
                case 2:
                    addToCart();
                    break;
                case 3:
                    cart.viewCart();
                    break;
                case 4:
                    double total = cart.checkout();
                    System.out.println("Checkout complete. Total amount: " + total);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void searchProducts() {
        inventory.listProducts();
    }

    private static void addToCart() {
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Product product = inventory.getProductById(productId);
        if (product != null) {
            cart.addProduct(product, quantity);
            System.out.println("Added " + quantity + " of " + product.getProductName() + " to the cart.");
        } else {
            System.out.println("Product not found.");
        }
    }
}