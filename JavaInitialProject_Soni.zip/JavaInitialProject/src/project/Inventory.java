package project;

import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private Map<Integer, Product> productList;

    public Inventory() {
        productList = new HashMap<>();
        // Hardcoded products
        productList.put(1, new Product(1, "Laptop", "Electronics", 1000.00));
        productList.put(2, new Product(2, "Smartphone", "Electronics", 500.00));
        productList.put(3, new Product(3, "Headphones", "Accessories", 150.00));
        productList.put(4, new Product(4, "Coffee Maker", "Appliances", 80.00));
    }

    public Product getProductById(int productId) {
        return productList.get(productId);
    }

    public void listProducts() {
        System.out.println("Available Products:");
        for (Product product : productList.values()) {
            System.out.println(product);
        }
    }
}